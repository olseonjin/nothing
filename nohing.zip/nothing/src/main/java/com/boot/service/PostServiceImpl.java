package com.boot.service;

import com.boot.dao.PostDAO;
import com.boot.dto.PostDTO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private SqlSession sqlSession;

    @Override
    public void insertPost(PostDTO post) {
        sqlSession.getMapper(PostDAO.class).insertPost(post);
    }

    @Override
    public List<PostDTO> getAllPosts() {
        return sqlSession.getMapper(PostDAO.class).getAllPosts();
    }

    @Override
    public PostDTO getPostById(int id) {
        return sqlSession.getMapper(PostDAO.class).getPostById(id);
    }

    @Override
    public void deletePostById(int id) {
        sqlSession.getMapper(PostDAO.class).deletePostById(id);
    }

	@Override
	public void deleteExpiredPosts() {
		// TODO Auto-generated method stub
		
	}
}