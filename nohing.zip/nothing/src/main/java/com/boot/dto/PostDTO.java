package com.boot.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PostDTO {
    private int id;
    private String imageUrl;
    private String caption;
    private String createdAt;
    private String expiresAt;
}