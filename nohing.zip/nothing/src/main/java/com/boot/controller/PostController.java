package com.boot.controller;

import com.boot.dto.PostDTO;
import com.boot.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Controller
public class PostController {

    @Autowired
    private PostService postService;

    @GetMapping("/index")
    public String index(Model model) {
        List<PostDTO> posts = postService.getAllPosts();
        model.addAttribute("posts", posts);
        return "index";
    }

    @PostMapping("/post")
    @ResponseBody
    public PostDTO uploadPost(@RequestParam("caption") String caption,
                               @RequestParam("imageFile") MultipartFile file) throws IOException {
        String uploadDir = "C:/uploads/"; // 반드시 이 폴더 존재해야 함
        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        File dest = new File(uploadDir + fileName);
        file.transferTo(dest);

        PostDTO dto = new PostDTO();
        dto.setCaption(caption);
        dto.setImageUrl("/uploads/" + fileName);
        postService.insertPost(dto);

        return dto;
    }

    @DeleteMapping("/post/delete/{id}")
    @ResponseBody
    public String deletePost(@PathVariable("id") int id) {
        postService.deletePostById(id);
        return "deleted";
    }
}
