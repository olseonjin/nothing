package com.boot.service;

import java.util.List;

import com.boot.dto.PostDTO;

public interface PostService {
	 void insertPost(PostDTO post);
	    List<PostDTO> getAllPosts();
	    PostDTO getPostById(int id);
	    void deleteExpiredPosts();
	    void deletePostById(int id);
}
