package com.boot.dao;

import com.boot.dto.PostDTO;
import java.util.List;

public interface PostDAO {
    void insertPost(PostDTO post);
    List<PostDTO> getAllPosts();
    PostDTO getPostById(int id);
    void deleteExpiredPosts();
    void deletePostById(int id);
}