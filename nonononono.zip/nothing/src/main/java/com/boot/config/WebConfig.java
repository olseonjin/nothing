package com.boot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 예: http://localhost:8485/uploads/6d17f5..._ex.jpg 로 브라우저 접근 가능하게 함
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:///C:/uploads/");  // 반드시 실제 폴더 경로와 일치
    }
}
